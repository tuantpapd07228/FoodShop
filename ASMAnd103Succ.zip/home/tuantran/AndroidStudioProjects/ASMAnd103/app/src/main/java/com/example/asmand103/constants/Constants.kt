package com.example.asmand103.constants

object Constants {
    const val BASE_URL ="http://172.16.53.57:3000/"
    const val BASE_URL_IMG = "$BASE_URL/images/"
    const val TAG = "ASMLOG"
    const val BASE_URL_GHN = "https://dev-online-gateway.ghn.vn/shiip/public-api/"
}