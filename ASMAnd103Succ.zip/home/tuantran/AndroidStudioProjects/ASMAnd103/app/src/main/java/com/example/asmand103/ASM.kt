package com.example.asmand103

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ASM : Application() {
}