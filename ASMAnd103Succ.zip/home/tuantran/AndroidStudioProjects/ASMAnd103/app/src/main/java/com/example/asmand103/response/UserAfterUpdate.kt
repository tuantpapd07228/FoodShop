package com.example.asmand103.response

data class UserAfterUpdate(
    val __v: Int,
    val _id: String,
    val age: Int,
    val available: Boolean,
    val avatar: String,
    val createdAt: String,
    val email: String,
    val name: String,
    val password: String,
    val updatedAt: String,
    val username: String
)