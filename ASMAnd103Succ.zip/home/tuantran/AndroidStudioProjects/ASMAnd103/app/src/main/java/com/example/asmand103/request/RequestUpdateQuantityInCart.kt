package com.example.asmand103.request

data class RequestUpdateQuantityInCart(
    val id:String,
    val quantity:Int
)
