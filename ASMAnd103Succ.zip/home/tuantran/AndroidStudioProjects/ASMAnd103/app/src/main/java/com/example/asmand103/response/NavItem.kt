package com.example.asmand103.response

data class NavItem(
    val icon: Int,
    val title: String
)
