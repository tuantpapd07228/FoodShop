package com.example.asmand103.request

data class RequestLogin(
    val username:String,
    val password:String
)
