package com.example.asmand103.request

data class Category(
    val level1: String
)